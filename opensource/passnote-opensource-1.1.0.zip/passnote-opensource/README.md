# PassNote

## Developer Directions

### data.json

Update placeholder items surrounded by "[\*" and "\*]" with appropriate items.

Placeholders surrounded by "[" and "]" should be left intact for the user to complete.